import pandas as pd

def preprocess(df):
    return df